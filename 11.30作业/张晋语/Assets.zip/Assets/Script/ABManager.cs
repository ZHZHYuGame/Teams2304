using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class ABManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Init();
    }

    private Dictionary<string,MyAssetBundle> abCache = new Dictionary<string,MyAssetBundle>();
    /// <summary>
    /// �����������е���Դ������ϵ������
    /// </summary>
    private Dictionary<string, string[]> allDependDict;
    /// <summary>
    /// AB��Դ·��
    /// </summary>
    private string abPath;

    private void Init()
    {
        abPath = Path.Combine(Application.streamingAssetsPath+"/ABs");
        InitDependence();
    }
    /// <summary>
    /// ��ʼ����Դ����������ϵ
    /// </summary>
    /// <exception cref="NotImplementedException"></exception>
    private void InitDependence()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

public class MyAssetBundle
{
    /// <summary>
    /// 
    /// </summary>
    public int count;

    public AssetBundle ab;

    public MyAssetBundle(AssetBundle ab)
    {
        count = 1;
        this.ab = ab;
    }
}

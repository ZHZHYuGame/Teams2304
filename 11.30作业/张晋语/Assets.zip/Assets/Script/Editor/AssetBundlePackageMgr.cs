﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

public class AssetBundlePackageMgr : Editor
{
    [MenuItem("Tool/AssetBundle/打包（正常）")]

    public static void CreateAssetBundle()
    {
        AssetBundleFiltrate();
        string outPath = $"{Application.streamingAssetsPath}";
        //检查目标目录是否存在
        if (!Directory.Exists(outPath))
        {
            //如果目录不存在，创建该目录（包括多级父目录）
            Directory.CreateDirectory(outPath);
        }
        // 构建资源包（AssetBundle）：
        // 参数1：输出路径（即上面定义的outPath）
        // 参数2：压缩方式（基于分块的压缩）
        // 参数3：构建目标平台（Windows独立程序）
        BuildPipeline.BuildAssetBundles(outPath,BuildAssetBundleOptions.ChunkBasedCompression,BuildTarget.StandaloneWindows);

        //启动进程，打开资源包输出目录（方便查看生成的资源包文件）
        Process.Start(outPath);
    }

    public static void AssetBundleFiltrate()
    {
        //设置需要筛选的文件格式类型
        string[] filtrateArr = new string[] { ".meta", ".pdf" };

        //获取到所需要打包的资源文件
        // 获取指定目录下的所有文件（包含子目录）
        // 参数1：目标目录路径（应用程序Data目录下的Resources/ABPackage文件夹）
        // 参数2：搜索的文件通配符（*.*表示所有类型的文件）
        // 参数3：搜索选项（AllDirectories表示包含所有子目录)
        string[] allFiles = Directory.GetFiles($"{Application.dataPath}/Resources/ABPackage","*.*",SearchOption.AllDirectories);

        // 判断筛除掉对应的文件格式类型资源文件，并得到筛除后的资源文件数组
        // Where(x => ...)：LINQ筛选，遍历allFiles中的每个文件x
        // Path.GetExtension(x)：获取文件x的后缀名（如.txt、.meta）
        // !filtrateArr.Contains(...)：判断文件后缀是否不在过滤数组filtrateArr中
        // ToArray()：将筛选后的结果转换为数组并重新赋值给allFiles
        allFiles = allFiles.Where((x)=> !filtrateArr.Contains(Path.GetExtension(x))).ToArray();

        StringBuilder sb= new StringBuilder();


        //最后得到资源打包
        foreach (var fp in allFiles)
        {
            // 1. 转换文件路径为Unity编辑器可识别的"Assets/"相对路径
            //  - Replace(@"\\", "/")：将Windows系统的反斜杠路径分隔符转为Unity统一的斜杠
            //  - Replace(Application.dataPath, "Assets")：把绝对路径（如"D:/Project/Assets/..."）替换为Unity内的相对路径（如"Assets/..."）
            string packPath = fp.Replace(@"\", "/").Replace(Application.dataPath, "Assets");

            //2.获取资源对应的AssetBundle名称：取文件的“无扩展名”名称作为AB包名
            string abName = Path.GetFileNameWithoutExtension(packPath);
            // 3. 获取该资源在Unity中的导入器（用于配置AssetBundle属性）
            AssetImporter importer =AssetImporter.GetAtPath(packPath);
            // 4. 设置当前资源所属的AssetBundle包名
            importer.assetBundleName = abName;
            // 5. 设置当前资源所属的AssetBundle扩展包名
            importer.assetBundleVariant = "u3d";
            //资源的MD5码（作为资源的改变判断）
            string md5 = GetMD5(fp);
            //拼成设计的资源模式（AB包资源名称+资源的）
            string abStr = $"{importer.assetBundleName}.{importer.assetBundleVariant}|{md5}";
            sb.AppendLine(abStr);
        }
        //保存资源清单文件
        SaveAssetsMainfast(sb.ToString());
        //保存版本号文件
        SaveAssetsVersion();
    }
    /// <summary>
    /// 保存版本号文件
    /// </summary>
    /// <exception cref="NotImplementedException"></exception>
    private static void SaveAssetsVersion()
    {
        // 将应用程序的版本号写入StreamingAssets目录下的AssetsVersion.txt文件
        // Application.streamingAssetsPath：Unity工程中StreamingAssets目录的路径（该目录文件会随包发布，可在运行时读取）
        // Application.version：Unity项目设置中配置的应用版本号（如"1.0.0"）
        // 作用：记录当前资源包对应的应用版本，常用于资源版本管理、热更新时的版本比对
        File.WriteAllText($"{Application.streamingAssetsPath}/Version.txt", Application.version);
    }
    /// <summary>
    /// 保存资源清单文件
    /// </summary>
    /// <param name="text"></param>
    private static void SaveAssetsMainfast(string text)
    {
        // 将指定文本内容写入StreamingAssets目录下的AssetsMainfast.txt文件
        // Application.streamingAssetsPath：Unity中StreamingAssets目录的路径（该目录下的文件会随构建包一起发布）
        // 路径拼接：拼接成"StreamingAssets/AssetsMainfast.txt"作为目标文件路径
        // 参数text：要写入的文本内容（通常是资源清单、配置信息等）
        File.WriteAllText($"{Application.streamingAssetsPath}/AssetMainfast.txt", text);
    }

    /// <summary>
    /// 转换一个资源的MD5码
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    private static string GetMD5(string path)
    {
        // 1. 读取目标文件的所有字节数据（将文件内容加载到内存）
        byte[] data=File.ReadAllBytes(path);
        // 2. 创建MD5加密服务提供者实例（用于计算哈希）
        MD5CryptoServiceProvider md5 =new MD5CryptoServiceProvider();
        // 3. 计算文件字节数据的MD5哈希值，得到16字节的哈希结果
        byte[] mData = md5.ComputeHash(data);
        // 4. 将字节数组形式的哈希值转换为字符串，并去除分隔符"-"
        // （BitConverter.ToString默认会用"-"分隔字节，如"AB-CD-EF"，替换后得到"ABCDEF..."）
        return BitConverter.ToString(mData).Replace("-","");
    }

    [MenuItem("Tool/AssetBundle/创建StreamingAssetsPath目录")]

    public static void CreateStreamingAssetsPath()
    {
        if (!Directory.Exists(Application.streamingAssetsPath))
        {
            Directory.CreateDirectory(Application.streamingAssetsPath);
        }
        //做为打包时的一些进入游戏之前的展示资源（模型、图片、动画、特效、剧情过场动画）的携带，跟着打包走
    }
    [MenuItem("Tool/AssetBundle/创建PersistentDataPath目录")]
    public static void ShowPersistentDataPath()
    {
        Process.Start(Application.persistentDataPath);
    }
}

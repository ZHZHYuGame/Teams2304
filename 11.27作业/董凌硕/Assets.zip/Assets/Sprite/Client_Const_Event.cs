using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Client_Const_Event
{

    /// <summary>
    /// �ͻ����ȸ�ȷ���¼�
    /// </summary>
    public const int Hotfix_Confirm_Event = 1001; // "Hotfix_Confirm_Event";
}

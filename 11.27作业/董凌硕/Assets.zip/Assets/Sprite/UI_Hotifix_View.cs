using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_Hotifix_View : MonoBehaviour
{
    public Button but_Confim;
    public Button but_Cancel;
    // Start is called before the first frame update
    void Start()
    {
        but_Confim.onClick.AddListener(() =>
        {
            /*  MessageControll.GetInstance().Dispach(Client_Const_Event.Hotfix_Confirm_Event);*/
            VersionAssetHotfixMgr.ins.Hotfix_Confirm_Event_Handle();
        });
        but_Cancel.onClick.AddListener(()=>
        {

        });
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;



public class AssBuidPageMgr : Editor
{
    [MenuItem("Tool/AssetBundle/打包（正常）")]
    public static void CreatAssBundle()
    {
        //
        AssetBundleFileBundle();
        //输出AB资源路径
        string outPath = $"{Application.dataPath}/Resources/ABFiles";
        //Debug.Log(Application.dataPath);
        Debug.Log(outPath);
        //using System.IO;检查文件是否存在，不存在就创建它
        if (!Directory.Exists(outPath))
        {
            Directory.CreateDirectory(outPath);
        }
        //编辑器提供的打包接口，输出路径，AB包的压缩方式，AB包的目标平台
        BuildPipeline.BuildAssetBundles(outPath, BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.StandaloneWindows);
        //自动打开（路径）文件夹
        Process.Start(outPath);
    }

    private static void AssetBundleFileBundle()
    {
        //定义需要过滤的文件类型
        string[] filtrateArr=new string[]{".meta",".pdf"};
        
        //获取这个路径下的所有文件
        string[] allFiles = Directory.GetFiles($"{Application.dataPath}/Resources/ABPackage", "*.*", SearchOption.AllDirectories);
        //where，保留符合的条件                ==》 //！是否包含的文件，获取文件完整 名称如（text.meta）.转换为数组，重新赋值给allFiles
        allFiles = allFiles.Where((x) => !filtrateArr.Contains(Path.GetExtension(x))).ToArray();
        StringBuilder sb = new StringBuilder();
        foreach (var fp in allFiles)
        {
            //将"\"换成"/"避免路径格式错误         //将（此项目绝对路径）替换为Assets//得到packPath路径
            string packPath=fp.Replace(@"\","/").Replace(Application.dataPath, "Assets");
            //获取文件名，不带后缀的文件名
            string abName = Path.GetFileNameWithoutExtension(packPath);
            //获取importer，根据路径导入对应的实例//AssetImporter的类型
            AssetImporter importer = AssetImporter.GetAtPath(packPath);
            //将当前AB包的名称=abName
            importer.assetBundleName=abName;
            //将当前AB包的变体="u3d"
            importer.assetBundleVariant="u3d";
            //资源的MD5码（做为资源的改变判定）
            string md5 = GetMD5(fp);
            //拼成设计的资源格式（AB包资源名 + 资源的MD5码）
            string abStr = $"{importer.assetBundleName}.{importer.assetBundleVariant}|{md5}";
            sb.AppendLine(abStr);
        }
        SaveAssetsMainfast(sb.ToString());
        SaveAssetsVersion();
    }
    [MenuItem("Tool/AssetBundle/创建StreamingAssetsPath目录")]
    public static void CreateStreamingAssetsPath()
    {
        if (!Directory.Exists(Application.streamingAssetsPath))
        {
            Directory.CreateDirectory(Application.streamingAssetsPath);
        }
        //做为打包时的一些进入游戏之前的展示资源（模型、图片、动画、特效、剧情过场动画）的携带，跟着打包走
    }
    [MenuItem("Tool/AssetBundle/创建PersistentDataPath目录")]
    public static void ShowPersistentDataPath()
    {
        Process.Start(Application.persistentDataPath);
    }

    /// <summary>
    /// 转化一个资源的MD5码
    /// </summary>
    /// <param name="path"></param>
    /// <returns></returns>
    private static string GetMD5(string path)
    {
        byte[] data = File.ReadAllBytes(path);
        MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
        byte[] mData = md5.ComputeHash(data);
        return BitConverter.ToString(mData).Replace("-", "");
    }
    /// <summary>
    /// 保存资源清单文件
    /// </summary>
    /// <param name="text"></param>
    static void SaveAssetsMainfast(string text)
    {
        File.WriteAllText($"{Application.streamingAssetsPath}/AssetMainfast.txt", text);
    }
    /// <summary>
    /// 保存版本号文件
    /// </summary>
    static void SaveAssetsVersion()
    {
        File.WriteAllText($"{Application.streamingAssetsPath}/Version.txt", Application.version);
    }
}



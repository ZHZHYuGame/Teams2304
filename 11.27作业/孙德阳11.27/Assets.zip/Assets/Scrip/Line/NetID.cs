using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetID
{
    /// <summary>
    ///世界聊天发送C_2_S-
    /// </summary>
    public static int C_To_S_WorldChat_Msg = 1001;
    public static int S_To_C_WorldChat_Msg = 1002;
    
    public static int C_To_S_PrivateChat_Msg = 1003;
    public static int S_To_C_PrivateChat_Msg = 1004;

}

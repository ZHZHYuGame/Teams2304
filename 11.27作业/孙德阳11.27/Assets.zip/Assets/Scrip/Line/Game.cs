using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Google;
using Google.Protobuf;
using MyGame;


public class Game : MonoBehaviour
{
    public Button WorldBtn, PrivateBtn;
    public Button btn;
    public InputField input;
    private int C_type;
    void Start()
    {
        NetManager net = new NetManager();
        net.Start();
        WorldBtn.onClick.AddListener(() =>
        {
            C_type = 1001;
        });
        PrivateBtn.onClick.AddListener(() =>
        {
            C_type = 1003;
        });
        btn.onClick.AddListener(() =>
        {
            Debug.Log("点击发送"+input.text);
            if (C_type!=0)
            {
                if (C_type==1001)
                {
                    C_To_S_WorldChat_Msg msg = new C_To_S_WorldChat_Msg();
                    msg.Type =(Chat_Type)C_type;
                    msg.Text = input.text;
                    net.SendData(C_type, msg.ToByteArray());
                }
                if (C_type==1003)
                {
                    C_To_T_WorldChat_Msg msg = new C_To_T_WorldChat_Msg();
                    msg.Type =(Chat_Type)C_type;
                    msg.SpeakPlayer = "";
                    msg.TargetPlayer = "";
                    msg.TextDesc = input.text;
                    net.SendData(C_type, msg.ToByteArray());
                }
            }
            
        });
    }

    // Update is called once per frame
    void Update()
    {

    }
}

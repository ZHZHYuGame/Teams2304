using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

public class NetManager 
{
    Socket st;
    public void Start()
    {
        Debug.Log("开始链接");
        st = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        //目标IP,目标端口号，连接成功回调，回调额外状态数据
        st.BeginConnect("127.0.0.1", 11008, Connect_To_Net_Handle, null);
    }

    private void Connect_To_Net_Handle(IAsyncResult ar)
    {
        st.EndConnect(ar);

        Debug.Log("连接成功,开始传数据");
    }

    public void SendData(int id,byte[] str)
    {
        Debug.Log("发送成功");
        //id的byte
        byte[] iddata = BitConverter.GetBytes(id);
        //这是要发送的包
        byte[] data = new byte[iddata.Length + str.Length];
        //复制的数组，开始位置，写入的数组，开始位置，写入的长度
        Buffer.BlockCopy(iddata, 0, data, 0, iddata.Length);
        Buffer.BlockCopy(str, 0, data, iddata.Length, str.Length);
        
        //打包方法
        byte[] realldata= MakeBao(data);
        
        //发送数据，
        st.BeginSend(realldata, 0, realldata.Length, 0, SendcallBack, null);
        
    }
/// <summary>
/// 打包方法
/// </summary>
/// <param name="data">包体！！！</param>
/// <returns></returns>
    private byte[] MakeBao(byte[] data)
    {
        using (MyMemoryStream ms = new MyMemoryStream())
        {
            ushort len=(ushort)data.Length;
            ms.WriteUShort(len);
            ms.Write(data, 0, data.Length);
            return ms.ToArray();
        }
    }

    private void SendcallBack(IAsyncResult ar)
    {
        int sentbytes=st.EndSend(ar);
        Debug.Log($"成功发送{sentbytes}字节数");
    }
}

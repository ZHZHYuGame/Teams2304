local shopItem=BaseClass("ShopItem")

function shopItem:__init(shopData,trans)
    self.gameobject=GameObject.Instantiate(Resources.Load("shopItem"),trans)
    --查找预制件
    self.name_txt=self.gameobject.transform:Find("name"):GetComponent(typeof(Text))
    self.icon_img=self.gameobject.transform:Find("icon"):GetComponent(typeof(Image))

    self:RefreshItem(shopData)
end

function shopItem:RefreshItem(shopData)
    self.name_txt.text=shopData.config.name
    self.icon_img.sprite=Resources.Load("icon/"..shopData.config.icon,typeof(Sprite))
end




return shopItem
local ShopView = BaseClass("ShopView")

function ShopView:__init(prefab)
    self.close=prefab.transform:Find("Close")
    self.close:GetComponent("Button").onClick:AddListener(function ()
        prefab.transform.gameObject:SetActive(false)
    end)
    self.gameObject=prefab

    --查找组件
    self.shopContent=self.gameObject.transform:Find("Content")
    self.shopItem=require("UI/Shop/Component/ShopItem")
end

function ShopView:OnEnable()

end

function ShopView:RefreshView(table)
print(#table)
    for index, value in ipairs(table) do
        self.shopItem.New(value,self.shopContent)
    end

end

return ShopView

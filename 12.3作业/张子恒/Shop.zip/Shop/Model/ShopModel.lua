local ShopModel = BaseClass("ShopModel")

function ShopModel:__init()
    self.shopDatas = {}
end
-- 设置商品数据（由Controller调用）
function ShopModel:SetShopDatas(datas)
    self.shopDatas = datas
end
-- 获取商品数据（给View提供数据）
function ShopModel:GetShopDatas()
    return self.shopDatas
end
return ShopModel

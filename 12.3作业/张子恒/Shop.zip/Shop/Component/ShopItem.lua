local shopItem=BaseClass("ShopItem")
function shopItem:__init(index,data,parent)
    self.index=index
    self.data=data
    self.shopitem=GameObject.Instantiate(Resources.Load("ShopItem",typeof(GameObject)),parent.transform)
    self.icon=self.shopitem.transform:GetChild(0):GetComponent("Image")
    self.numText=self.shopitem.transform:GetChild(1):GetComponent("Text")

    if data~=nil then
        self.icon.gameObject:SetActive(true)
        self.numText.gameObject:SetActive(true)
        self.icon.sprite=Resources.Load("icon/" .. self.data.Icon,typeof(Sprite))
        self.numText.text=self.data.Num
    else
        self.icon.gameObject:SetActive(false)
        self.numText.gameObject:SetActive(false)
    end
end
return shopItem
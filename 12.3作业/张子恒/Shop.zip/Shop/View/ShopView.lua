local ShopView = BaseClass("ShopView")
local ShopItem=require("UI/Shop/Component/ShopItem")
function ShopView:__init(prefab)
    self.uiPrefab = prefab -- 商城面板预制体
    -- 绑定UI组件（需和你的UI结构对应，比如ScrollView的Content）
    self.itemContent = prefab.transform:Find("ShopPanel/Scroll View/Viewport/Content") -- 商品项容器
end
-- 渲染商城商品列表
function ShopView:UpdateShopUI(data)
    self.shopdata=data
    for i = 0, self.shopdata.Count-1, 1 do
        ShopItem.New(i,self.shopdata[i],self.itemContent)
    end
end
return ShopView

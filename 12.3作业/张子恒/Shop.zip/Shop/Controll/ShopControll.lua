local ShopControll = BaseClass("ShopControll")

function ShopControll:__init()
	self:AddListener()
	
end
function ShopControll:S_To_C_Shop_Msg_Handle(data)
	self.model:SetShopDatas(data[1].ShopData)
	self.view:UpdateShopUI(data[1].ShopData)
end
function ShopControll:AddListener()
	-- 假设网络消息管理器是NetworkMgr，监听服务器的"S_To_C_Shop_Msg"消息
	NetMessageControll:AddListener(NetID.S_To_C_Shop_Msg,Bind(self,self.S_To_C_Shop_Msg_Handle))
end
-- 移除监听（防止内存泄漏）
function ShopControll:RemoveListener()
end

return ShopControll

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using Tutorial;
using UnityEngine;
using XLua;

public class UI_LuaEnvManager : Singleton<UI_LuaEnvManager>
{
    LuaEnv lua;
    Action start_Handle;
    Action update_Handle;
    // Start is called before the first frame update
    public  void Start()
    {
        lua = new LuaEnv();
        lua.AddLoader(CustomerLoader);
        lua.DoString("require'LuaMain'");
        start_Handle = lua.Global.Get<Action>("StartLua");
        update_Handle = lua.Global.Get<Action>("UpdataLua");
        start_Handle?.Invoke();
    }

    private byte[] CustomerLoader(ref string filepath)
    {
        string luaPath = "";
#if Window_Lua
        luaPath = $"{Application.dataPath}/Lua/{filepath}.lua";
#elif android_Lua
        luaPath = $"{Application.dataPath}/Lua/{filepath}.lua";
#endif
        return File.ReadAllBytes(luaPath);
    }

    // Update is called once per frame
    public void Update()
    {
        update_Handle?.Invoke();
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singleton<T>where T:class,new()
{
    private static T Ins;
    private static object obj = new object();
    public static T GetInstance()
    {
        if (Ins==null)
        {
            lock(obj)
            {
                if (Ins==null)
                {
                    Ins = new T();
                }
            }
        }
        return Ins;
    }
}

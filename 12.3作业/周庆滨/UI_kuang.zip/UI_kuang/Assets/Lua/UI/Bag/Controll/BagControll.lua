local bagcontroll=BaseClass("BagControll")

function bagcontroll:__init()
    
end


return bagcontroll
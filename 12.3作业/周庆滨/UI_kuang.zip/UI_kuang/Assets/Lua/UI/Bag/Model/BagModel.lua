local bagModel=BaseClass("BagMondel")

function bagModel:__init()
    
end


return bagModel
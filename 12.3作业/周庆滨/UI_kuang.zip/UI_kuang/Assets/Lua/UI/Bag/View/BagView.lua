local bagView=BaseClass("bagView")

function bagView:__init(prefab)
    self.gameobject=prefab
end

return bagView
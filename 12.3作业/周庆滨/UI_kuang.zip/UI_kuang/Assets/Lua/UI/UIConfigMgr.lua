UIConfigMgr={
    [UITypeEnum.bag]=require("UI/Bag/BagConfig"),
    --[UITypeEnum.shop]=require("UI/Bag/ShopConfig"),
    --[UITypeEnum.task]=require("UI/Bag/TaskConfig")
}
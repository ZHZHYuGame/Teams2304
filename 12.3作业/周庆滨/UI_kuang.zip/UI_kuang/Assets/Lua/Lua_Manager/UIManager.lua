local UIManager={}

function UIManager:Init()
    self.uiBackGroundLayer=GameObject.Find("uiBackGroundLayer")
    self.uiWindowLayer=GameObject.Find("uiWindowLayer")
    self.uiTipsLayer=GameObject.Find("uiTipsLayer")
    self.uisystemOpenLayer=GameObject.Find("uisystemOpenLayer")
    self.uiGuideLayer=GameObject.Find("uiGuideLayer")
    self.uiLoadingLayer=GameObject.Find("uiLoadingLayer")
    self.uiHttpLayer=GameObject.Find("uiHttpLayer")
end
function UIManager:ShowUI(uiType)
    if self.uiDict==nil then
        --UI缓存字典
        self.uiDict={}
    end
    --第一次打开面板
    if self.uiDict[uiType]==nil then
        local uiconfigdata=UIConfigMgr[uiType]
        local uiPre=GameObject.Instantiate(Resources.Load(uiconfigdata.prefabName),UILayer.window.transform)
        uiconfigdata.code_Model.New()
        local mono_code=uiconfigdata.code_View.New(uiPre)
        uiconfigdata.code_Controll.New()
        uiconfigdata.code_Controll.model=uiconfigdata.code_Model
        uiconfigdata.code_Controll.view=mono_code

        self.uiDict[uiType]=mono_code
    else
       self:GetUI(uiType)
       --数据赋值
    end
    
   
end

function UIManager:CloseUI(uiType)
    
end

function UIManager:GetUI(uiType)
    
end

return UIManager
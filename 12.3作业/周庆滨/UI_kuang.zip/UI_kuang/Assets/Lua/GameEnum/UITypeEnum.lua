UITypeEnum={
    bag=1,
    shop=2,
    task=3
}
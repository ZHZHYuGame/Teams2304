require("Lipus/BaseClass")
require("Lipus/head")
_G.UImgr=require("Lua_Manager/UIManager")
_G.UImgr:Init()
require("GameEnum/UILayer")
require("GameEnum/UITypeEnum")
require("UI/UIConfigMgr")
function StartLua()
    print("1");
end

function UpdataLua()
    print("2");
end
_G.UImgr:ShowUI(UITypeEnum.bag);
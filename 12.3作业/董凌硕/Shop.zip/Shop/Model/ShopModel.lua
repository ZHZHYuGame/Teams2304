-- 商城数据模型
ShopModel = BaseClass("ShopModel")

function ShopModel:__init()
    self.shopDataList = {} -- 存储商品数据
end

-- 更新商城数据
function ShopModel:UpdateShopData(dataList)
    self.shopDataList = dataList
end

-- 获取商品列表
function ShopModel:GetShopDataList()
    return self.shopDataList
end

return ShopModel

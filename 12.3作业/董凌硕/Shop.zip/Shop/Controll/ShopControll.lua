ShopControll = BaseClass("ShopControll")

function ShopControll:__init()
    print(1)
    self.model = nil -- 从UIManager获取ShopModel
    self.view = nil
    self:AddUIListener() -- 监听UI消息中心的刷新事件
    self:RequestShopData() -- 打开商城时请求数据

end

-- 监听UI消息中心的ShopDataRefreshed事件
function ShopControll:AddUIListener()
    NetMessageControll:AddListener(NetID.S_To_C_Get_ShopData_Msg, Bind(self, self.OnShopDataRefreshed))
end

-- 请求商城数据（调用NetManager发送请求）
function ShopControll:RequestShopData()
    print("开始请求商城数据") -- 新增调试日志
    NetManager:Send_GetShopDataRequest()
end

-- 数据刷新后更新Model并通知View
function ShopControll:OnShopDataRefreshed(shopDataList)
    print(shopDataList[1].ShopDataList)
    self.data = shopDataList[1].ShopDataList
	
    self.model:UpdateShopData(self.data) -- 更新Model数据
    --local view = _G.UImgr:GetView() -- 从UIManager获取ShopView
    if self.view then
        self.view:RefreshShopUI(self.model:GetShopDataList()) -- 刷新UI
    end
end

-- 移除监听（避免内存泄漏）
function ShopControll:RemoveUIListener()
  
end
-- 获取UI对应的Model（供Controller调用）

return ShopControll

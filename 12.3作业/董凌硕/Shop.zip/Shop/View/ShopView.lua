-- 商城视图
ShopView = BaseClass("ShopView")
ShopItem =  require("UI/Shop/View/ShopItem")
function ShopView:__init(prefab)
    self.prefab = prefab
    -- 商品列表容器
    self.goodsListRoot = prefab.transform:Find("ShopPanel/Scroll View/Viewport/Content", typeof(GameObject))
    self.prefab.gameObject:SetActive(false)
    -- 绑定关闭按钮
    self.shopClose = prefab.transform:GetChild(0):GetChild(1):GetComponent("Button")
    self.shopClose.onClick:AddListener(function()
        _G.UImgr:CloseUI(UITypeEnum.shop)
    end)
    

end

-- 刷新商城UI
function ShopView:RefreshShopUI(goodsList)

    print("开始刷新UI，商品数量：" .. goodsList.Count) -- 新增调试日志
    -- 清空旧Item
    for i = self.goodsListRoot.childCount, 1, -1 do
        GameObject.Destroy(self.goodsListRoot:GetChild(i - 1).gameObject)
    end
    for i = 0, goodsList.Count - 1, 1 do
        ShopItem.New(self.goodsListRoot, goodsList[i])
    end
    --生成新Item
   
end

function ShopView:OnEnable()
    -- self.prefab.gameObject:SetActive(true)
end

return ShopView

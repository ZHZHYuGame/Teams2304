ShopItem = BaseClass("ShopItem")
function ShopItem:__init(goodsListRoot, Data)
    self.Data = Data
    self.goodsListRoot = goodsListRoot
    -- 商品列表容器
   
    self.itemObj = GameObject.Instantiate(Resources.Load("Item"), goodsListRoot)
    local itemTrans = self.itemObj.transform
    --赋值UI
    itemTrans:Find("NameText"):GetComponent("Text").text = self.Data.Name
    itemTrans:Find("Icon"):GetComponent("Image").sprite = Resources.Load("icon/" .. Data.Icon, typeof(Sprite))
    itemTrans:Find("PriceText"):GetComponent("Text").text = "售价：" .. self.Data.Sale
end
return ShopItem

local ShopControll = BaseClass("ShopControll")

function ShopControll:__init()
	self:AddListener()
end

function ShopControll:AddListener()
	NetMessageControll:AddListener(NetID.S_To_C_GoodData_Msg, Bind(self, self.S_To_C_GoodData_Handle))
end

function ShopControll:RemoveListener()

end

function ShopControll:S_To_C_GoodData_Handle(shopGoods)
	self.m_data = shopGoods[1]
	self.view:ShowShopItem(self.m_data)
end

return ShopControll

local ShopItem = require("UI/Shop/ShopItem")
local ShopView = BaseClass("ShopView")
local parent
function ShopView:__init(prefab)
    parent = prefab.transform:GetChild(0).transform:GetChild(0):Find("itemParent").transform
end

function ShopView:OnEnable()

end

function ShopView:ShowShopItem(shopGoods)
    self.goods = shopGoods
    for i = 0, self.goods.Goodsdatalist.Count - 1 do
        ShopItem.New(self.goods.Goodsdatalist[i], parent)
    end
end

return ShopView

local ShopModel = BaseClass("ShopModel")

function ShopModel:__init()

end

return ShopModel

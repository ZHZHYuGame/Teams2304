local ShopItem = BaseClass("ShopItem")
function ShopItem:__init(data, parent)
    self.item = GameObject.Instantiate(Resources.Load("shopitem", typeof(GameObject)), parent)
    self.mydata = data
    self.icon = self.item.transform:Find("icon"):GetComponent("Image")
    self.name = self.item.transform:Find("name"):GetComponent("Text")
    self.sale = self.item.transform:Find("sale"):GetComponent("Text")
    if data ~= nil then
        self.icon.gameObject:SetActive(true)
        self.name.gameObject:SetActive(true)
        self.sale.gameObject:SetActive(true)
        self.icon.sprite = Resources.Load("Icon/" .. self.mydata.Icon, typeof(Sprite))

        self.name.text = self.mydata.Name

        self.sale.text = "售价:" .. self.mydata.Sale
    else
        self.icon.gameObject:SetActive(false)
        self.name.gameObject:SetActive(false)
        self.sale.gameObject:SetActive(false)
    end
end

return ShopItem

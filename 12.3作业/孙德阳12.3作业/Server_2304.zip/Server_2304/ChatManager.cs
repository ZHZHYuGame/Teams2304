﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Google;
using Google.Protobuf;
using MyGame;
/// <summary>
/// 服务器--处理聊天逻辑
/// </summary>
public class ChatManager : Singleton<ChatManager>
{
    /// <summary>
    /// 启动聊天逻辑处理器
    /// </summary>
    public void Start()
    {

        MessageControll.GetInstance().AddListener(NetID.C_To_S_WorldChat_Msg, C_To_S_WorldChat_Msg_Handle);
    }
    /// <summary>
    /// 私人聊天逻辑处理
    /// </summary>
    /// <param name="obj"></param>
    private void C_To_S_PrivateChat_Msg_Handle(object obj)
    {

    }
    /// <summary>
    /// 世界聊天逻辑处理
    /// </summary>
    /// <param name="obj"></param>
    private void C_To_S_WorldChat_Msg_Handle(object obj)
    {
        object[] objList = obj as object[];
        byte[] data = objList[0] as byte[];
        Socket st_Speak = objList[1] as Socket;
        //将客户端发来的消息Byte反序列化成对应的PB消息结构
        C_To_S_Chat_Msg c_Msg = C_To_S_Chat_Msg.Parser.ParseFrom(data);

        //转发给其他客户端
        List<Client> cList = NetManager.GetInstance().Get_ClientList();
        S_To_C_Chat_Msg s_Msg = new S_To_C_Chat_Msg();
        switch (c_Msg.CType)
        {
            case Chat_Type.World:
                foreach (var c in cList)
                {
                    s_Msg.Result = Chat_Result.Succ;
                    s_Msg.CType = Chat_Type.World;
                    s_Msg.TextDesc = c_Msg.TextDesc;
                    s_Msg.Speaker = Get_Speak_IP(st_Speak); //c_Msg.SpeakerId;
                    NetManager.GetInstance().SendMessage(NetID.S_To_C_WorldChat_Msg, s_Msg.ToByteArray(), c.st);
                }
                break;
            case Chat_Type.Private:
                Client toSpeak = Get_PrivateChat_Client(int.Parse(c_Msg.Friend));
                if (toSpeak == null)
                {
                    s_Msg.Result = Chat_Result.FriendNoLine;
                }
                else
                {
                    s_Msg.Result = Chat_Result.Succ;
                    s_Msg.CType = Chat_Type.Private;
                    s_Msg.Speaker = c_Msg.Speaker;
                    s_Msg.Friend = c_Msg.Friend;
                    s_Msg.TextDesc = c_Msg.TextDesc;
                }

                foreach (var c in cList)
                {
                    if ( c.st == st_Speak || (toSpeak != null && c.st == toSpeak.st))
                    {
                        NetManager.GetInstance().SendMessage(NetID.S_To_C_WorldChat_Msg, s_Msg.ToByteArray(), c.st);
                    }
                }

                    break;
            case Chat_Type.Bp:
                break;
            case Chat_Type.Lm:
                break;
            default:
                break;
        }


    }

    private string Get_Speak_IP(Socket st)
    {
        List<Client> cList = NetManager.GetInstance().Get_ClientList();

        foreach (var c in cList)
        {
            if (c.st == st)
            {
                return c.ip;
            }
        }
        return "";
    }

    Client Get_PrivateChat_Client(int index)
    {
        List<Client> cList = NetManager.GetInstance().Get_ClientList();

        return cList.Count < index ? null : NetManager.GetInstance().Get_ClientList()[index];
    }
}


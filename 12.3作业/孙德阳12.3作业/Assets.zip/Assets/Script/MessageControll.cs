﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class MessageControll:Singleton<MessageControll>
{
    Dictionary<int, Action<object>> dict = new Dictionary<int, Action<object>>();

    public void AddListener(int id, Action<object> act)
    {
        if (!dict.ContainsKey(id))
        {
            dict.Add(id, act);
        }
    }
    /// <summary>
    /// 消息中心触发事件判断
    /// </summary>
    /// <param name="id"></param>
    /// <param name="par">不定参的形参</param>
    public void Dispach(int id, params object[] par)
    {
        if (dict.ContainsKey(id))
        {
            dict[id]?.Invoke(par);
        }
    }
}


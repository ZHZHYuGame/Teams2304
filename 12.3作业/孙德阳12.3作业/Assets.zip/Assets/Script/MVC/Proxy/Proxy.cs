using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Proxy : Notifier, IProxy, INotifier
{

    public Proxy(string name, object data = null)
    {
        proxyName = name ?? proxyName;
        this.data = data;
    }
    public string proxyName { get; }

    public object data { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }

    public void OnRegister()
    {
        throw new System.NotImplementedException();
    }

    public void OnRemove()
    {
        throw new System.NotImplementedException();
    }
}

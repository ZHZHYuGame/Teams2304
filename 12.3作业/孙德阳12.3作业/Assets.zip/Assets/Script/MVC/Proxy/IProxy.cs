using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IProxy : INotifier
{
    string proxyName { get; }

    object data { set; get; }

    void OnRegister();

    void OnRemove();
}

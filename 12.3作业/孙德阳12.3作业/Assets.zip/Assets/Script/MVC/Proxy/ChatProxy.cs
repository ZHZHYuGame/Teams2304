using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChatProxy : Proxy
{

    public static string ProxyName = "ChatProxy";

    public ChatProxy(string name) : base(name)
    {

    }

    public void Chat_Update_Handle()
    {

    }
}

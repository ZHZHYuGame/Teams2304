using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using XLua;

public class LuaEnv_Mgr : Singleton<LuaEnv_Mgr>
{
    LuaEnv lua_Env;

    Action start_Handle;
    Action update_Handle;
    public void Start()
    {
        lua_Env = new LuaEnv();

        lua_Env.AddLoader(CustomLoaderHandle);

        lua_Env.DoString("require 'LuaMain'");
        //����C#����Lua��һЩȫ�ֽӿ�
        start_Handle = lua_Env.Global.Get<Action>("Lua_Start");

        update_Handle = lua_Env.Global.Get<Action>("Lua_Update");

        start_Handle?.Invoke();
    }

    private byte[] CustomLoaderHandle(ref string filepath)
    {
        string luaPath = $"{Application.dataPath}/Script/Lua/{filepath}.lua";

        return File.ReadAllBytes(luaPath);
    }

    // Update is called once per frame
    public void Update()
    {
        update_Handle?.Invoke();
    }

    public void OnDestory()
    {
        lua_Env.Dispose();
    }
}

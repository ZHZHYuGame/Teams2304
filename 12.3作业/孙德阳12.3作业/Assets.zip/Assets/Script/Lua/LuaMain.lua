
require("Common/BaseClass")
require("Common/head")
require("Common/LuaUtil")
require("Net/NetManager")
LuaNetManager:Init()
print("baseclass = ", _G.BaseClass)
_G.UImgr = require("Lua_Manager/UIManager")
_G.UImgr:Init()
require("GameEnum/UILayer")
require("GameEnum/UITypeEnum")
require("UI/UIConfigMgr")
require("Message/Net_MessageControll")
require("Net/NetID")
local json = require("Common/json")
shopitem = require("UI/Shop/component/shopitem")
function Lua_Start()
    --商城按钮
    ShopBtn = GameObject.Find("Canvas").transform:Find("ShopBtn"):GetComponent("Button")
    ShopBtn.onClick:AddListener(
        function ()
            _G.UImgr:ShowUI(UITypeEnum.shop)
            local c_msg = MyGame.C_To_S_Chat_Msg()
            NetManager.GetInstance():SendMessage(NetID.C_To_S_WorldChat_Msg, MessageExtensions.ToByteArray(c_msg));
            --print("发送成功")
        end
    )
end


function Lua_Update()

end

local c_Chat_Msg = MyGame.C_To_S_Chat_Msg()

print("chat msg = ", c_Chat_Msg)




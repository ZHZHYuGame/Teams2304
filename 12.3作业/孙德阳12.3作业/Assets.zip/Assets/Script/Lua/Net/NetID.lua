NetID = {
    C_To_S_WorldChat_Msg = 1001,
    S_To_C_WorldChat_Msg = 1002,
    C_To_S_PrivateChat_Msg = 1003,
    S_To_C_PrivateChat_Msg = 1004
}
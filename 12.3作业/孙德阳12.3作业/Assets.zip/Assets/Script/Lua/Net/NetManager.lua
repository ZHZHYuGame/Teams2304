LuaNetManager = BaseClass("NetManager")

function Handle_Net_Msg(netData)

    NetMessageControll:Dispatch(netData.netID, netData.byteData)
    print(netData.netID)

    
end

function LuaNetManager:Init()
    CShap_Handle_Lua_Tool.GetInstance():Bind_Net_To_Lua_Handle(Handle_Net_Msg)
end
-- function LuaNetManager:SendMessage(id,msg)
    
-- end

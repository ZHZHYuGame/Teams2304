local ShopControll = BaseClass("ShopControll")

function ShopControll:__init()
	self:AddListener()
end

function ShopControll:S_To_C_WorldChat_Msg_Handle(byteData)
	print("客户端收到请求")
	self.view:Xuanran(self.model.Equips)
end



function ShopControll:AddListener()
	NetMessageControll:AddListener(NetID.S_To_C_WorldChat_Msg, Bind(self,self.S_To_C_WorldChat_Msg_Handle));
	print("请求客户端")
end

function ShopControll:RemoveListener()

end

return ShopControll

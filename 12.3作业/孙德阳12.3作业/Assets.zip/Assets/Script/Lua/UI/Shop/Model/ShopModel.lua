local ShopModel = BaseClass("ShopModel")
local json = require("Common/json")

function ShopModel:__init()
    print("初始化解析商城数据")
    self.Equips = json.decode(Resources.Load("json/equip", typeof(TextAsset)).text)
    -- for key, value in pairs(Equips) do
    --     print(value.name)
    -- end
end

return ShopModel

local ShopView = BaseClass("ShopView")


function ShopView:__init(prefab)
self.Content = prefab.transform:Find("Scroll View/Viewport/Content")
-- print("self.Content=", self.Content)
-- print(self.Content)

end

function ShopView:OnEnable()

end
function ShopView:Xuanran(equips)
    for key, value in pairs(equips) do
        print(value.name)
        --print("self.Content=", self.Content)
        shopitem.New(value, self.Content)
        --GameObject.Instantiate(Resources.Load("shopitem",typeof(GameObject)),self.Content)
    end
end

return ShopView

local shopitem = BaseClass("shopitem")

function shopitem:__init(data, trans)

    self.root = GameObject.Instantiate(Resources.Load("shopitem",typeof(GameObject)), trans)
    self.icon = self.root.transform:Find("icon"):GetComponent("Image")
    self.name = self.root.transform:Find("name"):GetComponent("Text")
    self.price = self.root.transform:Find("price"):GetComponent("Text")
    self.buy = self.root.transform:Find("Buy"):GetComponent("Button")
    self.buy.onClick:AddListener(
        function ()
            print("购买" .. data.name)
        end
    )


    self:SetValue(data)
end
function shopitem:SetValue(data)

    
    self.icon.sprite = Resources.Load("icon/" .. data.icon,typeof(Sprite))
    self.name.text = data.name
    self.price.text = "售价：" .. data.sale
    
    
end

return shopitem 
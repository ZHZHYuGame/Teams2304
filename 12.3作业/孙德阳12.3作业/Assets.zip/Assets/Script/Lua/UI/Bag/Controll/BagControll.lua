--Controll层--业务逻辑层（客户端）
--所有触发修改变化的事件
--所有UI组件的响应事件
--数据到UI上刷新的指挥者

local bagControll = BaseClass("bagControll")

function bagControll:__init()
    self:AddListener()
end

function bagControll:AddListener()
    
end

function bagControll:RemoveListener()
    
end

function bagControll:OnEnable()
    
end

return bagControll
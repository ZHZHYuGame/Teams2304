local bagView = BaseClass("bagView")

function bagView:__init(prefab)
    self.gameobject = prefab
    --组件区定义查找
    self.btn = prefab.transform:Find(""):GetComponent("Button")
end

function bagView:OnEnable()
    
end

return bagView
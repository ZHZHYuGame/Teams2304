local bagModel = BaseClass("bagModel")

function bagModel:__init()
    
end

return bagModel
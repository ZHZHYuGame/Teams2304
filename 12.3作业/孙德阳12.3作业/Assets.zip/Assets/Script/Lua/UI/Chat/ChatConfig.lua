local UIChatConfig = {
	type = UITypeEnum.Chat,
	prefabName = "UI_Window_Chat",
	layer = UILayer.window,
	code_Model = require("UI/Chat/Model/ChatModel"),
	code_View = require("UI/Chat/View/ChatView"),
	code_Controll = require("UI/Chat/Controll/ChatControll"),
}
return UIChatConfig

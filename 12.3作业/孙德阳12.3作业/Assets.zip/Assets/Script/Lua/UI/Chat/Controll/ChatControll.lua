local ChatControll = BaseClass("ChatControll")

function ChatControll:__init()
	self:AddListener()
end

function ChatControll:S_To_C_WorldChat_Msg_Handle(byte)
	local data = MyGame.S_To_C_Chat_Msg.Parser:ParseFrom(byte)
	print("data = ", data)
	print("聊天内容 = ", data.TextDesc)
	
end

function ChatControll:AddListener()
	NetMessageControll:AddListener(NetID.S_To_C_WorldChat_Msg, self.S_To_C_WorldChat_Msg_Handle)
end

function ChatControll:RemoveListener()
end

return ChatControll

local ChatView = BaseClass("ChatView")

function ChatView:__init(prefab)

end

function ChatView:OnEnable()

end

return ChatView

local ChatModel = BaseClass("ChatModel")

function ChatModel:__init()

end

return ChatModel

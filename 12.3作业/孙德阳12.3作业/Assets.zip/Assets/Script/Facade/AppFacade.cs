using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AppFacade : Facade
{
    
    public override void Start()
    {
        base.Start();
        InitCommand();
        InitProxy();
    }

    
    void InitCommand()
    {
        RegisterCommand(NetID.S_To_C_WorldChat_Msg, () => new Chat_NetCommand());
    }
    private void InitProxy()
    {
        //RegisterProxy(new ChatProxy(ChatProxy.ProxyName));
    }

    public static AppFacade GetInstance()
    {
        return GetInstance(() => new AppFacade()) as AppFacade;
    }

}

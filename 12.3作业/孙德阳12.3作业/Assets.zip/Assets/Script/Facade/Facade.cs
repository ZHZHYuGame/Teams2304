using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Facade : IFacade
{
    public Controll controll;

    protected static IFacade instance;
    public virtual void Start()
    {
        controll = new Controll();
    }

    public void HasProxy()
    {
        
    }

    public void NotifyObservers(INotification notification)
    {
        
    }

    public void RegisterCommand(int tagName, Func<ICommand> cmd)
    {
        controll.RegisterCommand(tagName, cmd);
    }

    public void RegisterMediator()
    {
       
    }

    public void RegisterProxy(IProxy proxy)
    {
        
    }

    public void RemoveProxy()
    {
        
    }

    public IProxy RetrieveProxy(string name)
    {
        return Facade.GetInstance(()=>new Facade()).RetrieveProxy(name);
    }

    public static IFacade GetInstance(Func<IFacade> facadeFunc)
    {
        if (instance == null)
        {
            instance = facadeFunc();
        }
        return instance;
    }

    public void RegisterCommand(string tagName, Func<ICommand> cmd)
    {
        
    }
}

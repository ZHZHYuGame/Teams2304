using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Client_Const_Event
{
    /// <summary>
    /// �ͻ����ȸ�ȷ���¼�
    /// </summary>
    public const int Hotfix_Confirm_Event = 10001; //"Hotfix_Confirm_Event";

    public const int Hotfix_To_UI_Show = 10002;

}

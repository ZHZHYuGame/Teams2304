using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using ClassLibrary_2304;

public class Game : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        NetManager.GetInstance().Start();

        AppFacade.GetInstance().Start();
        
        LuaEnv_Mgr.GetInstance().Start();
        

        //Tool_Time_Manager.GetInstance().Delay_Handle_One(3, () =>
        //{
        //    Debug.Log("3���ִ�С�������������������������������?");
        //});
    }

    // Update is called once per frame
    void Update()
    {
        NetManager.GetInstance().Update();
        Tool_Time_Manager.GetInstance().Update();
        LuaEnv_Mgr.GetInstance().Update();
    }

    private void OnApplicationQuit()
    {
        NetManager.GetInstance().ExitGame();
    }
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Google;
using Google.Protobuf;
using MyGame;
using System;

public class UI_MainIcon : MonoBehaviour
{
    public Button btn;

    public Button btn_Private;

    public InputField in_Field;

    public InputField in_Field_Private;

    public Text txt_Desc;

    public GameObject UI_Hotfix_View;

    // Start is called before the first frame update
    void Start()
    {
        btn.onClick.AddListener(()=>
        {
            C_To_S_Chat_Msg msg = new C_To_S_Chat_Msg();
            msg.TextDesc = in_Field.text;
            msg.CType = Chat_Type.World;
            //msg.ToByteArray()   ������Ϣ--�������л�
            NetManager.GetInstance().SendMessage(NetID.C_To_S_WorldChat_Msg, msg.ToByteArray());
            
        });

        btn_Private.onClick.AddListener(() =>
        {
            C_To_S_Chat_Msg msg = new C_To_S_Chat_Msg();
            msg.TextDesc = in_Field.text;
            msg.CType = Chat_Type.Private;
            msg.Speaker = "";
            msg.Friend = in_Field_Private.text;
            //msg.ToByteArray()   ������Ϣ--�������л�
            NetManager.GetInstance().SendMessage(NetID.C_To_S_WorldChat_Msg, msg.ToByteArray());
        });

        MessageControll.GetInstance().AddListener(NetID.S_To_C_WorldChat_Msg, S_To_C_Chat_Msg_Handle);

        //MessageControll.GetInstance().AddListener(Client_Const_Event.Hotfix_To_UI_Show, Hotfix_To_UI_Show_Handle);
    }

    private void Hotfix_To_UI_Show_Handle(object obj)
    {
        UI_Hotfix_View.SetActive(true);
    }

    private void S_To_C_Chat_Msg_Handle(object obj)
    {
        object[] objList = obj as object[];
        byte[] data = objList[0] as byte[];
        bool state = (bool)objList[1];
        int value = int.Parse(objList[2].ToString());
        string s_Value = objList[3].ToString();
        int value1 = int.Parse(objList[4].ToString());


        S_To_C_Chat_Msg s_Msg = S_To_C_Chat_Msg.Parser.ParseFrom(data);

        switch (s_Msg.CType)
        {
            case Chat_Type.World:
                txt_Desc.text += $"�����硷{s_Msg.Speaker}˵:{s_Msg.TextDesc}\r\n";
                break;
            case Chat_Type.Private:
                //�ж�˵�����Ƿ����Լ�
                txt_Desc.text += $"<color=pink>��˽�ˡ������Ķ�{s_Msg.Friend}˵:{s_Msg.TextDesc}\r\n</color>";
                //txt_Desc.text += $"<color=pink>��˽�ˡ�{s_Msg.Speaker}���Ķ���˵:{s_Msg.TextDesc}\r\n</color>";
                break;
            case Chat_Type.Bp:
                break;
            case Chat_Type.Lm:
                break;
            default:
                break;
        }
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// ֪ͨ�ӿ�
/// </summary>
public interface INotification
{

    string name { get; }

    string type { get; }

    object body { set; get; }

    string toString { get; }

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Notification : INotification
{

    public Notification(string name, object body, string type)
    {
        this.name = name;
        this.body = body;
        this.type = type;
    }

    /// <summary>
    /// ��IDͬ��
    /// </summary>
    public string name { get; }

    public string type { set; get; }

    public object body { get; set; }

    public string toString { set; get; }

    public override string ToString() 
    {
        return "";
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IControll
{
    /// <summary>
    /// ע����������봦����Ϊ
    /// </summary>
    /// <param name="tagName"></param>
    /// <param name="cmd"></param>
    void RegisterCommand(int tagName, Func<ICommand> cmd);
    /// <summary>
    /// ������Ϊ
    /// </summary>
    /// <param name="tagName"></param>
    void ExecuteCommand(INotification notification);

    void HasCommand(int tagName);

    void RemoveCommand(int tagName);

}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetCommand : ICommand
{

    public virtual void Execute(INotification notification)
    {
        
    }
}

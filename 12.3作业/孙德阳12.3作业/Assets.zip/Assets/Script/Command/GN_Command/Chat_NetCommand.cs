using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Google;
using Google.Protobuf;
using MyGame;

public class Chat_NetCommand : GameCommand
{

    public override void Execute(INotification notification)
    {
        Debug.Log("����������Ϣ�����ִ��......");

        ChatProxy chat_Proxy = AppFacade.GetInstance().RetrieveProxy(ChatProxy.ProxyName) as ChatProxy;

        byte[] data_Byte = notification.body as byte[];

        S_To_C_Chat_Msg s_Msg = S_To_C_Chat_Msg.Parser.ParseFrom(data_Byte);

        notification.body = s_Msg;

        //chat_Proxy.Chat_Update_Handle(notification);
    }

}

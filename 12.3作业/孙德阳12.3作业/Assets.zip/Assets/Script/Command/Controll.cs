using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using UnityEngine;

public class Controll : IControll
{

    ConcurrentDictionary <int, Func<ICommand>> cmd_Dict = new ConcurrentDictionary<int, Func<ICommand>>();
    /// <summary>
    /// Execute == Boradcast or Dispatch
    /// </summary>
    /// <param name="notification"></param>
    public void ExecuteCommand(INotification notification)
    {
        Func<ICommand> func;
        if (cmd_Dict.TryGetValue(int.Parse(notification.name), out func))
        {
            ICommand cmd = func();
            cmd.Execute(notification);
        }
    }

    public void HasCommand(int tagName)
    {

    }

    public void RegisterCommand(int tagName, Func<ICommand> cmd)
    {
        if (!cmd_Dict.ContainsKey(tagName))
        {
            cmd_Dict.TryAdd(tagName, cmd);
        }
        else
        {
            cmd_Dict[tagName] += cmd;
        }
    }

    public void RemoveCommand(int tagName)
    {

    }
}

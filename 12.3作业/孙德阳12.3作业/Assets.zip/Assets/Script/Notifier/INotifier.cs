using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// ֪ͨ��Ϊ�ӿ�
/// </summary>
public interface INotifier
{

    void SendNotification(INotification notification);

}

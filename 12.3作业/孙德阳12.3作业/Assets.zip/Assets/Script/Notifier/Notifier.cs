using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Notifier : INotifier
{
    public virtual void SendNotification(INotification notification)
    {
        
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// �汾��
/// </summary>
public class VersionData
{
    public int big;
    public int middle;
    public int small;
    public string vStr;
    public VersionData(string verStr)
    {
        vStr = verStr;
        string[] verArr = verStr.Split('.');
        big = int.Parse(verArr[0]);
        middle = int.Parse(verArr[1]);
        small = int.Parse(verArr[2]);
    }

    public override string ToString()
    {
        return vStr;
    }
}

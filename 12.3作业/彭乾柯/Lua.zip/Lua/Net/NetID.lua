NetID = {
     C_To_S_GetShopInfos_msg = 1015,
     S_To_C_GetShopInfos_msg = 1016
}
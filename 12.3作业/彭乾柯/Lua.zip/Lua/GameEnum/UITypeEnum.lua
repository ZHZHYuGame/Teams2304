UITypeEnum = 
{
    bag = 1,
    shop = 2
}
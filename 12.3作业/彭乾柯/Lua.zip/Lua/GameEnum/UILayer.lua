UILayer = 
{
    backGround = _G.UImgr.UIBackGroundLayer,
    window = _G.UImgr.UIWindowLayer,
    tips = _G.UImgr.UITipsLayer,
    systemOpen = _G.UImgr.UISystemOpenLayer,
    guide = _G.UImgr.UIGuideLayer,
    Loading = _G.UImgr.UILoadingLayer,
    http = _G.UImgr.UIHttpLayer
}
UIConfigMgr = 
{
    [UITypeEnum.bag] = require("UI/Bag/BagConfig"),
    [UITypeEnum.shop] = require("UI/Shop/ShopConfig")
}
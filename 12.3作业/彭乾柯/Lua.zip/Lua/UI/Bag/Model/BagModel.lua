local bagModel = BaseClass("BagModel")

function bagModel:__init()
    
end

return bagModel
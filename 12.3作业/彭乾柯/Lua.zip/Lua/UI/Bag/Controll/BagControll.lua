local bagControll = BaseClass("BagControll")

function bagControll:__init()
    self:AddListener()
end


function bagControll:AddListener()
    
end

function bagControll:Remove()
    
end

return bagControll
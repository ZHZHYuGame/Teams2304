local bagView = BaseClass("BagView")

function bagView:__init(uiPre)
    self.gameObject = uiPre
end

return bagView
ConfigManager = BaseClass("ConfigManager")

function ConfigManager:Init()
    local str = Resources.Load("json/装备",typeof(TextAsset)).text

    self.shopConfig  = {}
    self.shopConfig = json.decode(str);

    
end

function ConfigManager:GetShopConfig(id)


    for index, value in ipairs(self.shopConfig) do
        
        if tostring(id) == value.id then
            return value
        end
    end
    print("不存在这个商品id==", id)
    return nil
end
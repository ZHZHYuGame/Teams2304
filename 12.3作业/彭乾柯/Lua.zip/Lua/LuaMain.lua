
require("Common/BaseClass")
require("Common/LuaUtil")
json = require("Common/json")
require("Common/head")
require("Config/ConfigManager")
ConfigManager:Init()
require("Net/NetID")
require("Message/Net_MessageControll")
require("Net/NetManager")
Net_Manager:Init()

_G.UImgr = require("Lua_Manager/UIManager")
_G.UImgr:Init()
require("GameEnum/UILayer")
require("GameEnum/UITypeEnum")
require("UI/UIConfigMgr")
function Lua_Start()
    -- print("Lua_Start")
    _G.UImgr:ShowUI(UITypeEnum.shop)

    local c_msg = MyGame.C_To_S_GetShopInfos_Msg()
    NetManager.GetInstance():SendMessage(NetID.C_To_S_GetShopInfos_msg,Protobuf.ToByteArray(c_msg))
end

function Lua_Update()
    
end


using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class VersionAssetsHotfixMgr : MonoBehaviour
{
    string http_Asset_Server_IP = "127.0.0.1/Game2304";
    // Start is called before the first frame update
    void Start()
    {
        //�汾���أ����ڱ���PĿ¼�µİ汾���ļ��Ա�
        string server_Verion_tex = $"{http_Asset_Server_IP}/Version.tex";
        Load_Asset_Server_Version(http_Asset_Server_IP, (data) =>
        {
            string s_Version_Str=BitConverter.ToString(data);
        });
    }

    private void Load_Asset_Server_Version(string path, Action<byte[]> complete)
    {
        
    }
    IEnumerator LoadGameAsset(string path, Action<byte[]> complete)
    {
        UnityWebRequest unityWeb = UnityWebRequest.Get(path);
        UnityWebRequestAsyncOperation op = unityWeb.SendWebRequest();
        if (op.isDone)
        {
            complete(unityWeb.downloadHandler.data);
        }
        yield return null;
    }
}

using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System;
using UnityEditor;
using UnityEngine;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// 资源包打包管理器
/// 用于处理AssetBundle的打包、路径管理等相关操作
/// </summary>
public class AssetBundlePackageMgr : Editor
{
    /// <summary>
    /// 菜单栏选项：Tool/AssetBundle/打包
    /// 执行AssetBundle的打包流程
    /// </summary>
    [MenuItem("Tool/AssetBundle/打包")]
    public static void CreateAssetBundle()
    {
        // 过滤并设置资源包信息
        AssetBundleFiltrate();

        // 打包输出路径（StreamingAssets目录）
        string outPath = $"{Application.streamingAssetsPath}";

        // 如果输出目录不存在则创建
        if (!Directory.Exists(outPath))
        {
            Directory.CreateDirectory(outPath);
        }

        // 执行打包操作：使用基于块的压缩，目标平台为Windows
        BuildPipeline.BuildAssetBundles(outPath, BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.StandaloneWindows);

        // 打开打包输出目录
        Process.Start(outPath);
    }

    /// <summary>
    /// 资源包过滤与配置
    /// 处理需要打包的资源，设置AssetBundle名称和变体，并生成资源清单
    /// </summary>
    public static void AssetBundleFiltrate()
    {
        // 需要过滤的文件扩展名
        string[] filtrateArr = new string[] { ".meta", ".pdf" };

        // 获取所有资源文件（ABPackage目录下）
        string[] allFiles = Directory.GetFiles($"{Application.dataPath}/Resources/ABPackage", "*.*", SearchOption.AllDirectories);

        // 过滤掉不需要打包的文件类型
        allFiles = allFiles.Where((x) => !filtrateArr.Contains(Path.GetExtension(x))).ToArray();

        StringBuilder sb = new StringBuilder();

        // 处理每个资源文件
        foreach (var fp in allFiles)
        {
            // 将文件路径转换为Unity资源路径格式（Assets/...）
            string packPath = fp.Replace(@"\", "/").Replace(Application.dataPath, "Assets");

            // 获取资源包名称（不带扩展名的文件名）
            string abName = Path.GetFileNameWithoutExtension(packPath);

            // 获取资源导入器
            AssetImporter importer = AssetImporter.GetAtPath(packPath);

            // 设置资源包名称
            importer.assetBundleName = abName;

            // 设置资源包变体
            importer.assetBundleVariant = "u3d";

            // 计算文件的MD5值（用于资源更新校验）
            string md5 = GetMD5(fp);

            // 拼接资源信息字符串（资源包名.变体|MD5）
            string abStr = $"{importer.assetBundleName}.{importer.assetBundleVariant}|{md5}";
            sb.AppendLine(abStr);
        }

        // 保存资源清单文件
        SaveAssetsMainfast(sb.ToString());

        // 保存版本文件
        SaveAssetsVersion();
    }

    /// <summary>
    /// 菜单栏选项：Tool/AssetBundle/StreamingAssetsPath目录
    /// 创建StreamingAssets目录（如果不存在）
    /// </summary>
    [MenuItem("Tool/AssetBundle/StreamingAssetsPathĿ¼")]
    public static void CreateStreamingAssetsPath()
    {
        if (!Directory.Exists(Application.streamingAssetsPath))
        {
            Directory.CreateDirectory(Application.streamingAssetsPath);
        }
        // 临时存放一些游戏启动前需要显示的资源，如模型、图片、音效等
    }

    /// <summary>
    /// 菜单栏选项：Tool/AssetBundle/PersistentDataPath目录
    /// 打开PersistentDataPath目录
    /// </summary>
    [MenuItem("Tool/AssetBundle/PersistentDataPathĿ¼")]
    public static void ShowPersistentDataPath()
    {
        Process.Start(Application.persistentDataPath);
    }

    /// <summary>
    /// 计算文件的MD5哈希值
    /// </summary>
    /// <param name="path">文件路径</param>
    /// <returns>MD5哈希字符串</returns>
    private static string GetMD5(string path)
    {
        byte[] data = File.ReadAllBytes(path);
        MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
        byte[] mData = md5.ComputeHash(data);
        return BitConverter.ToString(mData).Replace("-", "");
    }

    /// <summary>
    /// 保存资源清单文件
    /// 记录所有资源包的名称、变体和MD5信息
    /// </summary>
    /// <param name="text">清单内容</param>
    static void SaveAssetsMainfast(string text)
    {
        File.WriteAllText($"{Application.streamingAssetsPath}/AssetMainfast.txt", text);
    }

    /// <summary>
    /// 保存版本文件
    /// 记录当前应用版本号
    /// </summary>
    static void SaveAssetsVersion()
    {
        File.WriteAllText($"{Application.streamingAssetsPath}/Version.txt", Application.version);
    }
}